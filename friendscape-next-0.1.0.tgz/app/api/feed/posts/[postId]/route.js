import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentSession, touchSession } from '@/lib/auth';
import { serializePostForViewer } from '@/lib/posts';

const postInclude = {
  author: true,
  comments: {
    include: { author: true },
    orderBy: { createdAt: 'desc' },
  },
  votes: true,
  saves: true,
};

export async function GET(_request, { params }) {
  try {
    const session = await getCurrentSession();
    if (!session) return NextResponse.json({ error: 'Требуется авторизация.' }, { status: 401 });
    await touchSession(session.id);

    const { postId } = await params;
    const postIdNum = Number(postId);
    if (!Number.isInteger(postIdNum) || postIdNum <= 0) {
      return NextResponse.json({ error: 'Некорректный пост.' }, { status: 400 });
    }

    const post = await prisma.post.findUnique({
      where: { id: postIdNum },
      include: postInclude,
    });

    if (!post) return NextResponse.json({ error: 'Пост не найден.' }, { status: 404 });

    return NextResponse.json({
      post: await serializePostForViewer(post, session.user.id),
    }, {
      headers: { 'Cache-Control': 'no-store' },
    });
  } catch (error) {
    console.error('feed/post get failed', error);
    return NextResponse.json({ error: 'Не удалось загрузить публикацию.' }, { status: 500 });
  }
}
