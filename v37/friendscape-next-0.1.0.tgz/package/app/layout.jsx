import './globals.css';

export const metadata = {
  title: 'Friendscape',
  description: 'Friendscape',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
