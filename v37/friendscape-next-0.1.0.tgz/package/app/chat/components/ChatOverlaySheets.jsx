'use client';

import { canBatchSelectMessage, mediaPreviewLabel } from './chatViewPrimitives';
import { getMessageCapabilities } from '../lib/messageCapabilities';


export default function ChatOverlaySheets({
  forwardSheetOpen,
  forwardSourceMessages,
  closeForwardSheet,
  forwardTargetsQuery,
  setForwardTargetsQuery,
  selectedMessage,
  selectedMessageActionText,
  selectedMessagePreviewItems,
  messageActionLoading,
  composerMode,
  closeSelectedMessage,
  handleRetryMessage,
  beginReplyMessage,
  handleCopyMessage,
  openForwardSheet,
  beginMultiMessageSelection,
  beginEditMessage,
  handleToggleSaveMessage,
  handleTogglePinMessage,
  handleReportSelectedMessage,
  handleDeleteMessage,
  forwardTargetChats,
  forwardSelectedChatIds,
  toggleForwardChatSelection,
  forwardComment,
  setForwardComment,
  handleForwardSelectedMessage,
  forwardSubmitting,
  pinnedPanelOpen,
  closePinnedPanel,
  pinnedMessages,
  activePinnedEntry,
  setPinnedCurrentIndex,
  openPinnedMessage,
  attachmentSheetOpen,
  setAttachmentSheetOpen,
  launchAttachmentPicker,
  handleQuickReact,
  disableMessageActions,
}) {
  const messageCapabilities = getMessageCapabilities(selectedMessage);
  const quickReactions = ['❤️', '👍', '🔥', '😂', '😮', '😢'];
  const primaryActions = [
    selectedMessage?.state === 'failed' ? { key: 'retry', danger: false, warn: false, onClick: () => { handleRetryMessage(); closeSelectedMessage(); }, disabled: messageActionLoading, icon: '↺', label: 'Повторить' } : null,
    messageCapabilities.canReply && selectedMessage?.state !== 'failed' ? { key: 'reply', onClick: () => { beginReplyMessage(); closeSelectedMessage(); }, disabled: messageActionLoading || composerMode === 'edit', icon: '↩', label: 'Ответить' } : null,
    messageCapabilities.canCopy ? { key: 'copy', onClick: () => { handleCopyMessage(); }, disabled: messageActionLoading, icon: '⎘', label: 'Копировать' } : null,
    messageCapabilities.canForward ? { key: 'forward', onClick: () => { openForwardSheet(); closeSelectedMessage(); }, disabled: messageActionLoading || forwardSubmitting, icon: '➜', label: 'Переслать' } : null,
  ].filter(Boolean);
  const organizeActions = [
    canBatchSelectMessage(selectedMessage) ? { key: 'select-more', onClick: () => { beginMultiMessageSelection(); closeSelectedMessage(); }, disabled: messageActionLoading || forwardSubmitting, icon: '⊕', label: 'Выбрать ещё' } : null,
    messageCapabilities.canEdit ? { key: 'edit', onClick: () => { beginEditMessage(); closeSelectedMessage(); }, disabled: messageActionLoading, icon: '✎', label: 'Изменить' } : null,
    messageCapabilities.canSave ? { key: 'save', onClick: () => { handleToggleSaveMessage(); }, disabled: messageActionLoading, icon: '★', label: selectedMessage?.is_saved ? 'Убрать из сохранённых' : 'Сохранить' } : null,
    messageCapabilities.canPin ? { key: 'pin', onClick: () => { handleTogglePinMessage(); }, disabled: messageActionLoading, icon: '📌', label: selectedMessage?.is_pinned ? 'Открепить' : 'Закрепить' } : null,
  ].filter(Boolean);
  const cautionActions = [
    messageCapabilities.canReport ? { key: 'report', onClick: () => { handleReportSelectedMessage(); }, disabled: messageActionLoading, icon: '⚑', label: 'Пожаловаться', warn: true } : null,
    messageCapabilities.canDelete ? { key: 'delete', onClick: () => { handleDeleteMessage(); }, disabled: messageActionLoading, icon: '⌫', label: selectedMessage?.state === 'failed' ? 'Убрать' : 'Удалить', danger: true } : null,
  ].filter(Boolean);

  const orderedActions = [...primaryActions, ...organizeActions, ...cautionActions];

  return (
    <>
      {selectedMessage && !disableMessageActions ? (
        <div className="chatW-messageSheetBackdrop" onClick={closeSelectedMessage}>
          <div className="chatW-messageSheet" role="dialog" aria-modal="true" aria-label="Действия с сообщением" onClick={(event) => event.stopPropagation()}>
            <div className="chatW-messageSheetHandle" aria-hidden="true" />
            <div className="chatW-messageSheetHead">
              <div className="chatW-messageSheetHeadMain">
                <div className="chatW-messageSheetEyebrow">Сообщение</div>
                <div className="chatW-messageSheetTitle">{selectedMessageActionText || 'Действия с сообщением'}</div>
              </div>
              <button type="button" className="chatW-messageSheetClose" onClick={closeSelectedMessage} disabled={messageActionLoading} aria-label="Закрыть действия с сообщением">×</button>
            </div>
            <div className="chatW-messageSheetPreviewCard">
              <div className="chatW-messageSheetPreviewText">{selectedMessage?.forwarded_from?.preview_text || selectedMessage?.text || selectedMessage?.preview_text || mediaPreviewLabel(selectedMessage?.type, selectedMessage?.media)}</div>
              <div className="chatW-messageSheetMeta">
                <span>{selectedMessage?.sender?.name || (selectedMessage?.direction === 'outgoing' ? 'Вы' : 'Пользователь')}</span>
                {selectedMessage?.time ? <span>{selectedMessage.time}</span> : null}
              </div>
            </div>
            {messageCapabilities.canReact ? (
              <div className="chatW-messageSheetReactions">
                {quickReactions.map((emoji) => {
                  const isActive = Array.isArray(selectedMessage?.reactions) && selectedMessage.reactions.some((entry) => entry?.emoji === emoji && entry?.reacted_by_me);
                  return (
                    <button
                      key={emoji}
                      type="button"
                      className={`chatW-messageReactionChip ${isActive ? 'is-active' : ''}`}
                      onClick={() => { handleQuickReact?.(selectedMessage, emoji); closeSelectedMessage(); }}
                      disabled={messageActionLoading}
                    >
                      {emoji}
                    </button>
                  );
                })}
              </div>
            ) : null}
            {orderedActions.length ? (
              <div className="chatW-messageSheetList">
                {orderedActions.map((action) => (
                  <button
                    key={action.key}
                    type="button"
                    className={`chatW-messageSheetAction ${action.danger ? 'is-danger' : action.warn ? 'is-warn' : ''}`}
                    onClick={action.onClick}
                    disabled={action.disabled}
                  >
                    <span className="chatW-messageSheetActionIcon">{action.icon}</span>
                    <span>{action.label}</span>
                  </button>
                ))}
              </div>
            ) : null}
          </div>
        </div>
      ) : null}


      {forwardSheetOpen && forwardSourceMessages.length ? (
        <div className="chatW-forwardBackdrop" onClick={closeForwardSheet}>
          <div className="chatW-forwardSheet" role="dialog" aria-modal="true" aria-label="Переслать сообщение" onClick={(event) => event.stopPropagation()}>
            <div className="chatW-forwardHead">
              <div>
                <div className="chatW-forwardTitle">{forwardSourceMessages.length > 1 ? 'Переслать сообщения' : 'Переслать сообщение'}</div>
                <div className="chatW-forwardText">Можно выбрать один или несколько чатов.</div>
              </div>
              <button type="button" className="chatW-forwardClose" onClick={closeForwardSheet} aria-label="Закрыть">×</button>
            </div>
            <div className="chatW-forwardSearch">
              <input
                type="text"
                placeholder="Найти чат"
                value={forwardTargetsQuery}
                onChange={(event) => setForwardTargetsQuery(event.target.value)}
              />
            </div>
            <div className="chatW-forwardPreview">
              <strong>{forwardSourceMessages.length > 1 ? `Выбрано сообщений: ${forwardSourceMessages.length}` : (selectedMessage?.sender?.name || (selectedMessage?.is_mine ? 'Вы' : 'Пользователь'))}</strong>
              <span>{selectedMessagePreviewItems.join(' • ')}</span>
            </div>
            <div className="chatW-forwardList">
              {forwardTargetChats.length ? forwardTargetChats.map((chat) => {
                const checked = forwardSelectedChatIds.includes(chat.id);
                return (
                  <label key={chat.id} className={`chatW-forwardItem ${checked ? 'is-selected' : ''}`}>
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleForwardChatSelection(chat.id)}
                    />
                    <div className="chatW-forwardItemMain">
                      <strong>{chat.name}</strong>
                      <span>{chat.status || chat.preview || 'Диалог'}</span>
                    </div>
                  </label>
                );
              }) : <div className="chatW-forwardEmpty">Ничего не найдено.</div>}
            </div>
            <div className="chatW-forwardComment">
              <textarea
                rows={3}
                placeholder="Комментарий перед пересылкой (необязательно)"
                value={forwardComment}
                onChange={(event) => setForwardComment(event.target.value)}
              />
            </div>
            <div className="chatW-forwardActions">
              <button type="button" className="chatW-forwardCancel" onClick={closeForwardSheet} disabled={forwardSubmitting}>Отмена</button>
              <button type="button" className="chatW-forwardSubmit" onClick={handleForwardSelectedMessage} disabled={forwardSubmitting || !forwardSelectedChatIds.length}>{forwardSubmitting ? 'Пересылаем…' : 'Переслать'}</button>
            </div>
          </div>
        </div>
      ) : null}

      {pinnedPanelOpen ? (
        <div className="chatW-forwardBackdrop" onClick={closePinnedPanel}>
          <div className="chatW-forwardSheet chatW-pinnedSheet" role="dialog" aria-modal="true" aria-label="Закреплённые сообщения" onClick={(event) => event.stopPropagation()}>
            <div className="chatW-forwardHead">
              <div>
                <div className="chatW-forwardTitle">Закреплённые сообщения</div>
                <div className="chatW-forwardText">Быстрый переход к важным сообщениям в этом чате.</div>
              </div>
              <button type="button" className="chatW-forwardClose" onClick={closePinnedPanel} aria-label="Закрыть">×</button>
            </div>
            <div className="chatW-pinnedList">
              {pinnedMessages.length ? pinnedMessages.map((entry, index) => {
                const isActive = entry.message?.id && entry.message.id === activePinnedEntry?.message?.id;
                return (
                  <button
                    key={entry.id || entry.message?.id || index}
                    type="button"
                    className={`chatW-pinnedItem ${isActive ? 'is-active' : ''}`}
                    onClick={() => { setPinnedCurrentIndex(index); openPinnedMessage(entry.message?.id); }}
                  >
                    <strong>{entry.message?.sender?.name || 'Пользователь'}</strong>
                    <span>{entry.message?.forwarded_from?.preview_text || entry.message?.text || entry.message?.preview_text || mediaPreviewLabel(entry.message?.type, entry.message?.media)}</span>
                    <em>{entry.message?.time || ''}</em>
                  </button>
                );
              }) : <div className="chatW-forwardEmpty">Пока нет закреплённых сообщений.</div>}
            </div>
          </div>
        </div>
      ) : null}

      {attachmentSheetOpen ? (
        <div className="chatW-attachsheet-backdrop" onClick={() => setAttachmentSheetOpen(false)}>
          <div className="chatW-attachsheet" role="dialog" aria-modal="true" aria-label="Добавить вложение" onClick={(event) => event.stopPropagation()}>
            <div className="chatW-attachsheet-head">
              <div>
                <div className="chatW-attachsheet-title">Вложения</div>
              </div>
              <button type="button" className="chatW-attachsheet-close" onClick={() => setAttachmentSheetOpen(false)} aria-label="Закрыть">×</button>
            </div>
            <div className="chatW-attachsheet-grid">
              <button type="button" className="chatW-attachsheet-option" onClick={() => launchAttachmentPicker({ kind: 'image', accept: 'image/*' })}>
                <span className="chatW-attachsheet-option-title">Фото</span>
                <span className="chatW-attachsheet-option-text">Можно выбрать несколько</span>
              </button>
              <button type="button" className="chatW-attachsheet-option" onClick={() => launchAttachmentPicker({ kind: 'video', accept: 'video/*' })}>
                <span className="chatW-attachsheet-option-title">Видео</span>
                <span className="chatW-attachsheet-option-text">Можно выбрать несколько</span>
              </button>
              <button type="button" className="chatW-attachsheet-option chatW-attachsheet-option-full" onClick={() => launchAttachmentPicker({ kind: 'file', accept: '*' })}>
                <span className="chatW-attachsheet-option-title">Файл</span>
                <span className="chatW-attachsheet-option-text">Можно выбрать несколько</span>
              </button>
            </div>
            <button type="button" className="chatW-attachsheet-cancel" onClick={() => setAttachmentSheetOpen(false)}>Отмена</button>
          </div>
        </div>
      ) : null}
    </>
  );
}
