import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentSession, touchSession, verifyCsrf } from '@/lib/auth';
import { writeAuditLog } from '@/lib/audit';
import { attachCommentVotes, commentInclude, serializeComment } from '@/lib/comments';

export async function PUT(request, { params }) {
  let session = null;
  try {
    const csrf = verifyCsrf(request);
    if (!csrf.ok) return csrf.response;

    session = await getCurrentSession();
    if (!session) {
      return NextResponse.json({ error: 'Требуется авторизация.' }, { status: 401 });
    }

    await touchSession(session.id);

    const { id } = await params;
    const commentId = Number(id);
    if (!Number.isFinite(commentId)) {
      return NextResponse.json({ error: 'Некорректный комментарий.' }, { status: 400 });
    }

    const body = await request.json();
    const text = String(body.text || '').trim().slice(0, 1000);
    if (!text) {
      return NextResponse.json({ error: 'Введите текст комментария.' }, { status: 400 });
    }

    const existing = await prisma.comment.findUnique({ where: { id: commentId } });
    if (!existing) {
      return NextResponse.json({ error: 'Комментарий не найден.' }, { status: 404 });
    }

    if (existing.authorId !== session.user.id) {
      return NextResponse.json({ error: 'Можно редактировать только свои комментарии.' }, { status: 403 });
    }

    const updated = await prisma.comment.update({
      where: { id: commentId },
      data: { text },
      include: commentInclude,
    });
    const [hydrated] = await attachCommentVotes([updated]);

    await writeAuditLog({
      request,
      session,
      action: 'comment.update',
      entityType: 'comment',
      entityId: commentId,
      metadata: { postId: existing.postId, length: text.length },
    });

    return NextResponse.json({ comment: serializeComment(hydrated, session.user.id), message: 'Комментарий обновлён.' });
  } catch (error) {
    console.error('comment/update failed', error);
    await writeAuditLog({
      request,
      session,
      action: 'comment.update',
      entityType: 'comment',
      status: 'error',
      metadata: { message: error?.message || 'unknown_error' },
    });
    return NextResponse.json({ error: 'Не удалось обновить комментарий.' }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  let session = null;
  try {
    const csrf = verifyCsrf(request);
    if (!csrf.ok) return csrf.response;

    session = await getCurrentSession();
    if (!session) {
      return NextResponse.json({ error: 'Требуется авторизация.' }, { status: 401 });
    }

    await touchSession(session.id);

    const { id } = await params;
    const commentId = Number(id);
    if (!Number.isFinite(commentId)) {
      return NextResponse.json({ error: 'Некорректный комментарий.' }, { status: 400 });
    }

    const existing = await prisma.comment.findUnique({ where: { id: commentId } });
    if (!existing) {
      return NextResponse.json({ error: 'Комментарий не найден.' }, { status: 404 });
    }

    if (existing.authorId !== session.user.id) {
      return NextResponse.json({ error: 'Можно удалять только свои комментарии.' }, { status: 403 });
    }

    await prisma.comment.delete({ where: { id: commentId } });

    await writeAuditLog({
      request,
      session,
      action: 'comment.delete',
      entityType: 'comment',
      entityId: commentId,
      metadata: { postId: existing.postId },
    });

    return NextResponse.json({ ok: true, deleted_id: commentId, post_id: existing.postId, message: 'Комментарий удалён.' });
  } catch (error) {
    console.error('comment/delete failed', error);
    await writeAuditLog({
      request,
      session,
      action: 'comment.delete',
      entityType: 'comment',
      status: 'error',
      metadata: { message: error?.message || 'unknown_error' },
    });
    return NextResponse.json({ error: 'Не удалось удалить комментарий.' }, { status: 500 });
  }
}
