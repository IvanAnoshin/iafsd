import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentSession, touchSession } from '@/lib/auth';
import { collectUserMedia } from '@/lib/profile-media';

export async function GET(_request, { params }) {
  try {
    const session = await getCurrentSession();
    if (!session) return NextResponse.json({ error: 'Требуется авторизация.' }, { status: 401 });
    await touchSession(session.id);

    const userId = Number((await params).id);
    if (!Number.isFinite(userId)) {
      return NextResponse.json({ error: 'Некорректный пользователь.' }, { status: 400 });
    }

    const posts = await prisma.post.findMany({
      where: { authorId: userId },
      orderBy: { createdAt: 'desc' },
      take: 80,
      include: { author: true },
    });

    const media = collectUserMedia(posts, session.user.id);
    return NextResponse.json({ items: media.items, counts: media.counts }, { headers: { 'Cache-Control': 'no-store' } });
  } catch (error) {
    console.error('users/media get failed', error);
    return NextResponse.json({ error: 'Не удалось загрузить медиа пользователя.' }, { status: 500 });
  }
}
