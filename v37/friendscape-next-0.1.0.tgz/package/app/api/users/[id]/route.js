import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { getCurrentSession } from '@/lib/auth';
import { ensureUserPublicProfile } from '@/lib/profile';
import { getSocialCounts } from '@/lib/social';

function sortFriendPair(a, b) {
  return a < b ? [a, b] : [b, a];
}

function buildMutualText(count) {
  if (!count) return 'Пока без общих знакомых';
  return `${count} общих знакомых`;
}

function initialsOf(firstName, lastName) {
  return `${String(firstName || '').trim().charAt(0)}${String(lastName || '').trim().charAt(0)}`.toUpperCase();
}

export async function GET(request, { params }) {
  try {
    const session = await getCurrentSession();
    if (!session) {
      return NextResponse.json({ error: 'Требуется авторизация.' }, { status: 401 });
    }

    const userId = Number((await params).id);
    if (!userId) {
      return NextResponse.json({ error: 'Некорректный пользователь.' }, { status: 400 });
    }

    const ensured = await ensureUserPublicProfile(userId);
    if (!ensured?.publicProfile) {
      return NextResponse.json({ error: 'Профиль не найден.' }, { status: 404 });
    }

    const profile = {
      ...ensured.publicProfile,
      user: ensured,
    };

    const [friendships, targetFriendships, incomingRequest, outgoingRequest, isFollowing, followsYou] = await prisma.$transaction([
      prisma.friendship.findMany({
        where: { OR: [{ userAId: session.user.id }, { userBId: session.user.id }] },
      }),
      prisma.friendship.findMany({
        where: { OR: [{ userAId: userId }, { userBId: userId }] },
      }),
      prisma.friendRequest.findUnique({
        where: { fromUserId_toUserId: { fromUserId: userId, toUserId: session.user.id } },
      }),
      prisma.friendRequest.findUnique({
        where: { fromUserId_toUserId: { fromUserId: session.user.id, toUserId: userId } },
      }),
      prisma.subscription.findUnique({
        where: { fromUserId_toUserId: { fromUserId: session.user.id, toUserId: userId } },
      }),
      prisma.subscription.findUnique({
        where: { fromUserId_toUserId: { fromUserId: userId, toUserId: session.user.id } },
      }),
    ]);

    const socialCounts = await getSocialCounts(userId, prisma);

    const currentFriendIds = new Set(friendships.map((item) => (item.userAId === session.user.id ? item.userBId : item.userAId)));
    const targetFriendIds = new Set(targetFriendships.map((item) => (item.userAId === userId ? item.userBId : item.userAId)));
    let mutualCount = 0;
    currentFriendIds.forEach((friendId) => {
      if (targetFriendIds.has(friendId)) mutualCount += 1;
    });

    const [userAId, userBId] = sortFriendPair(session.user.id, userId);
    const friendship = await prisma.friendship.findUnique({ where: { userAId_userBId: { userAId, userBId } } });

    return NextResponse.json({
      profile: {
        id: profile.user.id,
        name: `${profile.user.firstName} ${profile.user.lastName}`.trim(),
        first_name: profile.user.firstName,
        last_name: profile.user.lastName,
        handle: `@${profile.handle}`,
        handle_raw: profile.handle,
        bio: profile.bio || '',
        occupation: profile.occupation || '',
        city: profile.city || '',
        relationship_status: profile.relationshipStatus || '',
        tone: profile.tone,
        status: profile.status,
        initials: initialsOf(profile.user.firstName, profile.user.lastName),
        mutual: buildMutualText(Math.max(mutualCount, profile.mutualHint || 0)),
        mutualCount: Math.max(mutualCount, profile.mutualHint || 0),
        followersCount: socialCounts.followersCount,
        subscriptionsCount: socialCounts.subscriptionsCount,
        friendsCount: socialCounts.friendsCount,
        relation: friendship ? 'friends' : incomingRequest?.status === 'pending' ? 'incoming_request' : outgoingRequest?.status === 'pending' ? 'outgoing_request' : 'none',
        isFollowing: Boolean(isFollowing),
        followsYou: Boolean(followsYou),
      },
    });
  } catch (error) {
    console.error('users/get failed', error);
    return NextResponse.json({ error: 'Не удалось загрузить профиль.' }, { status: 500 });
  }
}
