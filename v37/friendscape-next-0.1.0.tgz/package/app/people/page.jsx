'use client';

import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import PostAuthBottomNav from '../../components/PostAuthBottomNav';
import { performSocialAction } from '@/lib/social-client';
import { readPageCache, writePageCache } from '@/lib/page-cache';

function SearchIcon() {
  return <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>;
}

function PlusIcon() {
  return <svg viewBox="0 0 24 24"><path d="M12 5v14" /><path d="M5 12h14" /></svg>;
}

function CheckIcon() {
  return <svg viewBox="0 0 24 24"><path d="M20 6 9 17l-5-5" /></svg>;
}

function MessageIcon() {
  return <svg viewBox="0 0 24 24"><path d="M5 6.5A3.5 3.5 0 0 1 8.5 3h7A3.5 3.5 0 0 1 19 6.5v4A3.5 3.5 0 0 1 15.5 14H10l-4 4v-4.5A3.5 3.5 0 0 1 5 10.5z"></path></svg>;
}

function UserIcon() {
  return <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"></circle><path d="M5 20a7 7 0 0 1 14 0"></path></svg>;
}

function PeopleAvatar({ initials, tone, status }) {
  return (
    <div className={`peopleM-avatar is-${tone}`}>
      <span>{initials}</span>
      {status === 'online' ? <span className="peopleM-online-dot" /> : null}
    </div>
  );
}

const PEOPLE_CACHE_KEY = 'page:people';
const PEOPLE_CACHE_TTL = 2 * 60 * 1000;

function actionConfig(relation) {
  if (relation === 'friends') {
    return { label: 'В друзьях', action: 'remove_friend', className: 'is-followed' };
  }
  if (relation === 'outgoing_request') {
    return { label: 'Заявка отправлена', action: 'cancel_request', className: 'is-pending' };
  }
  if (relation === 'incoming_request') {
    return { label: 'Принять заявку', action: 'accept_request', className: '' };
  }
  return { label: 'Добавить в друзья', action: 'send_request', className: '' };
}

export default function PeoplePage() {
  const router = useRouter();
  const initialCacheRef = useRef(null);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [requests, setRequests] = useState([]);
  const [people, setPeople] = useState([]);
  const [busyKey, setBusyKey] = useState('');
  const skipSearchReloadRef = useRef(true);

  useLayoutEffect(() => {
    const cachedState = readPageCache(PEOPLE_CACHE_KEY, PEOPLE_CACHE_TTL);
    initialCacheRef.current = cachedState;
    if (!cachedState) return;
    setQuery(cachedState.query || '');
    setFilter(cachedState.filter || 'all');
    setMessage(cachedState.message || '');
    setRequests(Array.isArray(cachedState.requests) ? cachedState.requests : []);
    setPeople(Array.isArray(cachedState.people) ? cachedState.people : []);
    setLoading(false);
  }, []);

  const loadPeople = async (nextQuery = query, nextFilter = filter, { silent = false } = {}) => {
    try {
      if (!silent) setLoading(true);
      setError('');
      const params = new URLSearchParams();
      if (nextQuery) params.set('query', nextQuery);
      if (nextFilter) params.set('filter', nextFilter);

      const response = await fetch(`/api/people?${params.toString()}`, { cache: 'no-store' });
      const data = await response.json();
      if (response.status === 401) {
        router.replace('/');
        return;
      }
      if (!response.ok) throw new Error(data.error || 'Не удалось загрузить людей.');

      setRequests(data.requests || []);
      setPeople(data.people || []);
    } catch (loadError) {
      setError(loadError.message || 'Не удалось загрузить людей.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPeople(query, filter, { silent: Boolean(initialCacheRef.current) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (skipSearchReloadRef.current) {
      skipSearchReloadRef.current = false;
      return undefined;
    }
    const timeout = setTimeout(() => {
      loadPeople(query, filter, { silent: Boolean(initialCacheRef.current && !error) });
    }, 180);
    return () => clearTimeout(timeout);
  }, [query, filter, error]);

  useEffect(() => {
    if (!people.length && !requests.length && loading) return;
    writePageCache(PEOPLE_CACHE_KEY, { query, filter, message, requests, people });
  }, [query, filter, message, requests, people, loading]);

  const totalCount = useMemo(() => people.length, [people]);

  const runAction = async (targetUserId, action) => {
    try {
      const key = `${targetUserId}:${action}`;
      setBusyKey(key);
      setError('');
      setMessage('');
      const data = await performSocialAction(targetUserId, action);
      if (data.message) setMessage(data.message);
      await loadPeople(query, filter);
    } catch (actionError) {
      setError(actionError.message || 'Не удалось выполнить действие.');
    } finally {
      setBusyKey('');
    }
  };

  const openProfile = (id) => router.push(`/profile/${id}`);
  const openChat = (person) => {
    const params = new URLSearchParams({ user: String(person.id), name: person.name }).toString();
    router.push(`/chat?${params}`);
  };

  return (
    <div className="app-shell">
      <div className="app profile-app peopleM-app">
        <main className="screen peopleM-screen">
          <section className="peopleM-hero">
            <div>
              <div className="peopleM-title">Люди</div>
              <div className="peopleM-subtitle">Друзья, подписки и новые контакты.</div>
            </div>
          </section>

          <section className="peopleM-searchbar">
            <SearchIcon />
            <input
              type="text"
              placeholder="Поиск по имени, нику или городу"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </section>

          <section className="peopleM-filters" aria-label="Фильтры людей">
            <button type="button" className={filter === 'all' ? 'active' : ''} onClick={() => setFilter('all')}>Все</button>
            <button type="button" className={filter === 'online' ? 'active' : ''} onClick={() => setFilter('online')}>Онлайн</button>
            <button type="button" className={filter === 'mutual' ? 'active' : ''} onClick={() => setFilter('mutual')}>Общие</button>
          </section>

          {error ? <div className="peopleM-alert is-error">{error}</div> : null}
          {message ? <div className="peopleM-alert is-success">{message}</div> : null}

          {requests.length > 0 ? (
            <section className="peopleM-section">
              <div className="peopleM-section-head">
                <div className="peopleM-section-title">Запросы в друзья</div>
                <div className="peopleM-section-meta">{requests.length}</div>
              </div>

              <div className="peopleM-listSurface">
                {requests.map((person) => (
                  <article key={person.id} className="peopleM-rowCard">
                    <button type="button" className="peopleM-rowMain" onClick={() => openProfile(person.id)}>
                      <PeopleAvatar initials={person.initials} tone={person.tone} status="online" />
                      <div className="peopleM-rowCopy">
                        <div className="peopleM-rowHead">
                          <div className="peopleM-name">{person.name}</div>
                          <div className="peopleM-handle">{person.handle}</div>
                        </div>
                        <div className="peopleM-note">{person.note}</div>
                        <div className="peopleM-rowTags">
                          <span>{person.mutual}</span>
                          <span>Хочет добавить вас</span>
                        </div>
                      </div>
                    </button>

                    <div className="peopleM-rowActions compact">
                      <button
                        type="button"
                        className="peopleM-lineAction primary"
                        disabled={busyKey === `${person.id}:accept_request`}
                        onClick={() => runAction(person.id, 'accept_request')}
                      >
                        {busyKey === `${person.id}:accept_request` ? '...' : <><CheckIcon /> Принять</>}
                      </button>
                      <button
                        type="button"
                        className="peopleM-lineAction subtle"
                        disabled={busyKey === `${person.id}:reject_request`}
                        onClick={() => runAction(person.id, 'reject_request')}
                      >
                        {busyKey === `${person.id}:reject_request` ? '...' : 'Отклонить'}
                      </button>
                      <button type="button" className="peopleM-iconAction" onClick={() => openChat(person)}>
                        <MessageIcon />
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            </section>
          ) : null}

          <section className="peopleM-section">
            <div className="peopleM-section-head">
              <div className="peopleM-section-title">Для вас</div>
              <div className="peopleM-section-meta">{loading ? '...' : totalCount}</div>
            </div>

            {loading ? (
              <div className="peopleM-card-placeholder">Загрузка списка людей...</div>
            ) : people.length === 0 ? (
              <div className="peopleM-card-placeholder">Никого не найдено. Попробуйте изменить поиск или фильтр.</div>
            ) : (
              <div className="peopleM-listSurface">
                {people.map((person) => {
                  const friendAction = actionConfig(person.relation);
                  const friendBusy = busyKey === `${person.id}:${friendAction.action}`;
                  const followAction = person.isFollowing ? 'unfollow' : 'follow';
                  const followBusy = busyKey === `${person.id}:${followAction}`;

                  return (
                    <article key={person.id} className="peopleM-rowCard">
                      <button type="button" className="peopleM-rowMain" onClick={() => openProfile(person.id)}>
                        <PeopleAvatar initials={person.initials} tone={person.tone} status={person.status} />
                        <div className="peopleM-rowCopy">
                          <div className="peopleM-rowHead">
                            <div className="peopleM-name">{person.name}</div>
                            <div className="peopleM-handle">{person.handle}</div>
                          </div>
                          <div className="peopleM-note">{person.meta}</div>
                          <div className="peopleM-rowTags">
                            <span>{person.mutual}</span>
                            <span>{person.friendsCount} друзей</span>
                            {person.followsYou ? <span>Подписан на вас</span> : null}
                          </div>
                        </div>
                      </button>

                      <div className="peopleM-rowActions">
                        <button
                          type="button"
                          className={`peopleM-lineAction primary ${friendAction.className}`}
                          disabled={friendBusy}
                          onClick={() => runAction(person.id, friendAction.action)}
                        >
                          {friendBusy ? '...' : friendAction.label}
                        </button>
                        <button
                          type="button"
                          className={`peopleM-lineAction secondary ${person.isFollowing ? 'is-active' : ''}`}
                          disabled={followBusy}
                          onClick={() => runAction(person.id, followAction)}
                        >
                          {followBusy ? '...' : person.isFollowing ? 'Подписка' : 'Подписаться'}
                        </button>
                        <button type="button" className="peopleM-iconAction" onClick={() => openChat(person)}>
                          <MessageIcon />
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </section>
        </main>

        <PostAuthBottomNav />
      </div>
    </div>
  );
}
