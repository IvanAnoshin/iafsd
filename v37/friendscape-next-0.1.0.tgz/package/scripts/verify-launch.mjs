import fs from 'fs';
import path from 'path';

const root = process.cwd();
const requiredRoutes = [
  'app/api/ready/route.js',
  'app/api/version/route.js',
  'app/api/auth/session/route.js',
  'app/api/feed/route.js',
  'app/api/people/route.js',
  'app/api/chats/route.js',
  'app/api/notifications/route.js',
  'app/api/support/tickets/route.js',
  'app/api/admin/analytics/overview/route.js',
  'app/api/admin/launch/verification/route.js',
];
const requiredPages = ['app/feed/page.jsx', 'app/people/page.jsx', 'app/profile/page.jsx', 'app/chat/page.jsx', 'app/settings/page.jsx'];
const requiredModels = ['User', 'Session', 'Post', 'Comment', 'Notification', 'SupportTicket', 'PostReport', 'Conversation', 'ChatMessage', 'UserDevice'];

function exists(rel) {
  return fs.existsSync(path.join(root, rel));
}

function read(rel) {
  return fs.readFileSync(path.join(root, rel), 'utf8');
}

const routeErrors = requiredRoutes.filter((rel) => !exists(rel));
const pageErrors = requiredPages.filter((rel) => !exists(rel));
const schema = exists('prisma/schema.prisma') ? read('prisma/schema.prisma') : '';
const missingModels = requiredModels.filter((name) => !new RegExp(`model\\s+${name}\\s+\\{`).test(schema));
const topLevel = fs.readdirSync(root);
const middlewareFiles = topLevel.filter((name) => /^middleware\.(js|mjs|cjs|ts|tsx)$/.test(name));
const proxyFiles = topLevel.filter((name) => /^proxy\.(js|mjs|cjs|ts|tsx)$/.test(name));
const packageJson = JSON.parse(read('package.json'));
const scripts = packageJson.scripts || {};
const requiredScripts = ['dev', 'build', 'start', 'prisma:generate', 'prisma:push', 'verify:launch'];
const missingScripts = requiredScripts.filter((name) => !scripts[name]);

const warnings = [];
if (!proxyFiles.length) warnings.push('proxy file missing');
if (middlewareFiles.length && proxyFiles.length) warnings.push(`proxy/middleware conflict: ${[...proxyFiles, ...middlewareFiles].join(', ')}`);
if (!exists('.env.example')) warnings.push('.env.example missing');

const errors = [];
if (routeErrors.length) errors.push(`missing routes: ${routeErrors.join(', ')}`);
if (pageErrors.length) errors.push(`missing pages: ${pageErrors.join(', ')}`);
if (missingModels.length) errors.push(`missing prisma models: ${missingModels.join(', ')}`);
if (missingScripts.length) errors.push(`missing package scripts: ${missingScripts.join(', ')}`);

const summary = {
  checked_at: new Date().toISOString(),
  status: errors.length ? 'error' : warnings.length ? 'warn' : 'ready',
  routes_checked: requiredRoutes.length,
  pages_checked: requiredPages.length,
  models_checked: requiredModels.length,
  warnings,
  errors,
};

console.log(JSON.stringify(summary, null, 2));
if (errors.length) process.exit(1);
