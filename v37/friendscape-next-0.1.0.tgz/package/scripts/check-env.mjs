const required = ['DATABASE_URL', 'APP_PUBLIC_URL'];
const missing = required.filter((key) => !String(process.env[key] || '').trim());

if (missing.length) {
  console.error(`[env] Missing required variables: ${missing.join(', ')}`);
  process.exit(1);
}

let publicUrl;
try {
  publicUrl = new URL(process.env.APP_PUBLIC_URL);
} catch {
  console.error('[env] APP_PUBLIC_URL must be a valid absolute URL.');
  process.exit(1);
}

if (process.env.NODE_ENV === 'production' && publicUrl.protocol !== 'https:') {
  console.error('[env] APP_PUBLIC_URL must use https in production.');
  process.exit(1);
}

const sameSite = String(process.env.SESSION_COOKIE_SAME_SITE || 'lax').toLowerCase();
if (!['lax', 'strict', 'none'].includes(sameSite)) {
  console.error('[env] SESSION_COOKIE_SAME_SITE must be one of: lax, strict, none');
  process.exit(1);
}

console.log('[env] Environment looks good.');
