import { spawn, spawnSync } from 'node:child_process';

const isWindows = process.platform === 'win32';
const npxCmd = isWindows ? 'npx.cmd' : 'npx';

function runStep(label, args) {
  const result = spawnSync(npxCmd, args, { stdio: 'inherit', shell: false });
  if (result.status !== 0) {
    console.error(`\n[dev bootstrap] ${label} failed.`);
    process.exit(result.status || 1);
  }
}

console.log('[dev bootstrap] syncing Prisma client and database...');
runStep('prisma generate', ['prisma', 'generate']);
runStep('prisma db push', ['prisma', 'db', 'push']);
console.log('[dev bootstrap] Prisma is ready. Starting Next dev server...\n');

const nextProcess = spawn(npxCmd, ['next', 'dev'], {
  stdio: 'inherit',
  shell: false,
  env: process.env,
});

nextProcess.on('exit', (code, signal) => {
  if (signal) {
    process.kill(process.pid, signal);
    return;
  }
  process.exit(code ?? 0);
});
