# Messenger pre-launch smoke checklist

## Core chat
- Open chat list, archived chats, and requests
- Send a text message and verify preview/unread updates
- Edit and delete a message
- Retry a failed media message

## Media
- Upload image, video, and file attachments
- Record and send a voice message
- Open video note flow and verify fallback if camera is unavailable

## Calls
- Start an audio call and end it cleanly
- Verify video call fallback to audio when camera is missing
- Confirm call status updates in another tab

## Realtime
- Presence refresh after reconnect
- Typing indicator appears and clears
- Unread counters sync across tabs

## UX and accessibility
- No debug panels in normal mode
- Keyboard focus ring is visible on chat controls
- Error notices are compact and disappear automatically
- Reduced motion mode removes chat transitions

## Safety and production checks
- Rate limits enabled in production env
- Permissions-Policy allows microphone/camera only for self
- Upload limits are configured
- Hidden debug mode still works through `?debug=1`
