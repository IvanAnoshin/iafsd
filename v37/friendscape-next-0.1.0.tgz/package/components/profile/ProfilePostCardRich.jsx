'use client';

import { useMemo, useState } from 'react';

function formatDateTime(value) {
  if (!value) return 'Только что';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Только что';
  return date.toLocaleString('ru-RU', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatName(authorName, fallback) {
  return authorName || fallback || 'Пользователь';
}

function getSlides(post) {
  const payload = post?.payload || {};
  if (Array.isArray(payload.slides)) return payload.slides;
  if (Array.isArray(payload.gallery)) {
    return payload.gallery.map((item, index) => ({
      bg: item?.preview || item?.background || item?.bg || 'linear-gradient(135deg, #b7c1ff, #95d7ff 55%, #afe5cc)',
      text: item?.title || item?.caption || item?.subtitle || `Фото ${index + 1}`,
    }));
  }
  if (Array.isArray(payload.media)) {
    const mediaSlides = payload.media
      .filter((item) => (item?.kind || 'photo') === 'photo')
      .map((item, index) => ({
        bg: item?.preview || item?.background || item?.bg || 'linear-gradient(135deg, #b7c1ff, #95d7ff 55%, #afe5cc)',
        text: item?.title || item?.caption || `Фото ${index + 1}`,
      }));
    return mediaSlides;
  }
  return [];
}

function getContentKind(post) {
  const payload = post?.payload || {};
  if (post?.type === 'video' || payload.video) return 'video';
  if (post?.type === 'link' || payload.link) return 'link';
  if (post?.type === 'repost' || payload.repost) return 'repost';
  if (getSlides(post).length) return 'gallery';
  return 'text';
}

function CommentInlineActions({ comment, busyKey, onCommentVote, onCommentEdit, onCommentDelete }) {
  return (
    <div className="profilePost-commentActionsInline">
      <button
        type="button"
        className={`comment-reaction-btn plus ${comment.current_vote === 1 ? 'active' : ''}`}
        disabled={busyKey === `comment-vote:${comment.id}`}
        onClick={() => onCommentVote?.(comment.id, comment.current_vote === 1 ? 0 : 1)}
      >
        <svg viewBox="0 0 24 24"><path d="M12 5v14"></path><path d="M5 12h14"></path></svg>
      </button>
      <span className="profilePost-commentCount is-plus">{comment.stats?.plus || 0}</span>
      <button
        type="button"
        className={`comment-reaction-btn minus ${comment.current_vote === -1 ? 'active' : ''}`}
        disabled={busyKey === `comment-vote:${comment.id}`}
        onClick={() => onCommentVote?.(comment.id, comment.current_vote === -1 ? 0 : -1)}
      >
        <svg viewBox="0 0 24 24"><path d="M5 12h14"></path></svg>
      </button>
      <span className="profilePost-commentCount is-minus">{comment.stats?.minus || 0}</span>
      {comment.is_mine ? (
        <>
          <button type="button" className="profilePost-inlineTextBtn" onClick={() => onCommentEdit?.(comment)} disabled={busyKey === `comment-edit:${comment.id}`}>Изменить</button>
          <button type="button" className="profilePost-inlineTextBtn is-danger" onClick={() => onCommentDelete?.(comment)} disabled={busyKey === `comment-delete:${comment.id}`}>Удалить</button>
        </>
      ) : null}
    </div>
  );
}

export default function ProfilePostCardRich({
  post,
  authorName,
  authorHandle,
  authorInitial,
  showAuthor = false,
  allowDelete = false,
  allowSave = false,
  busyKey = '',
  onToggleLike,
  onToggleSave,
  onAddComment,
  onCommentVote,
  onCommentEdit,
  onCommentDelete,
  onDelete,
}) {
  const [expanded, setExpanded] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [galleryIndex, setGalleryIndex] = useState(0);
  const [commentText, setCommentText] = useState('');
  const payload = post.payload || {};
  const slides = useMemo(() => getSlides(post), [post]);
  const kind = useMemo(() => getContentKind(post), [post]);

  const submitComment = async () => {
    const text = commentText.trim();
    if (!text || !onAddComment) return;
    const ok = await onAddComment(post.id, text);
    if (ok) setCommentText('');
  };

  const metaText = payload.meta || `${formatDateTime(post.created_at)}${post.location ? ` · ${post.location}` : ''}`;

  return (
    <article className="feed-post-card profilePost-richCard">
      <div className="feed-post-header">
        <div className="feed-post-user">
          <div className="feed-post-avatar">{authorInitial || 'P'}</div>
          <div className="feed-post-user-info">
            <div className="feed-post-name">{showAuthor ? formatName(authorName) : 'Публикация профиля'}</div>
            <div className="feed-post-meta">{showAuthor && authorHandle ? `${authorHandle} · ${metaText}` : metaText}</div>
          </div>
        </div>
        <div className="profilePost-topActions">
          {allowDelete ? (
            <button type="button" className="profilePost-topDelete" disabled={busyKey === `delete:${post.id}`} onClick={() => onDelete?.(post.id)}>
              Удалить
            </button>
          ) : null}
        </div>
      </div>

      <div className="feed-post-text-wrap">
        <div className={`feed-post-text ${expanded ? '' : 'collapsed'}`}>{post.text}</div>
        {post.text?.length > 140 ? (
          <button className="feed-post-more-btn" type="button" onClick={() => setExpanded((v) => !v)}>{expanded ? 'Скрыть' : 'Ещё'}</button>
        ) : null}
      </div>

      {kind === 'gallery' && slides.length ? (
        <div className="feed-post-content-block feed-post-gallery is-active">
          <div className="feed-post-gallery-track">
            {slides.length > 1 ? (
              <>
                <button className="feed-post-gallery-nav feed-post-gallery-prev" type="button" aria-label="Предыдущий слайд" onClick={() => setGalleryIndex((galleryIndex - 1 + slides.length) % slides.length)}>
                  <svg viewBox="0 0 24 24"><path d="M15 18 9 12l6-6"></path></svg>
                </button>
                <button className="feed-post-gallery-nav feed-post-gallery-next" type="button" aria-label="Следующий слайд" onClick={() => setGalleryIndex((galleryIndex + 1) % slides.length)}>
                  <svg viewBox="0 0 24 24"><path d="m9 18 6-6-6-6"></path></svg>
                </button>
              </>
            ) : null}
            {slides.map((slide, index) => (
              <div key={`${post.id}-${index}`} className={`feed-post-slide ${index === galleryIndex ? 'active' : ''}`} style={{ backgroundImage: slide.bg }}>
                <span>{slide.text}</span>
              </div>
            ))}
          </div>
          {slides.length > 1 ? (
            <div className="feed-post-gallery-bottom">
              <div className="feed-post-gallery-dots">
                {slides.map((_, index) => (
                  <button key={index} className={`feed-post-gallery-dot ${index === galleryIndex ? 'active' : ''}`} type="button" onClick={() => setGalleryIndex(index)} />
                ))}
              </div>
              <div className="feed-post-gallery-counter">{galleryIndex + 1} / {slides.length}</div>
            </div>
          ) : null}
        </div>
      ) : null}

      {kind === 'video' ? (
        <div className="feed-post-content-block feed-post-video-card is-active">
          <div className="video-poster"><div className="play-btn" aria-hidden="true"></div></div>
          <div className="feed-post-video-title">{payload.title || 'Видео из профиля'}</div>
          <div className="feed-post-video-desc">{payload.desc || payload.caption || 'Видео сохранено в профиле пользователя.'}</div>
        </div>
      ) : null}

      {kind === 'link' ? (
        <div className="feed-post-content-block feed-post-link-card is-active">
          {payload.domain ? <div className="link-domain">{payload.domain}</div> : null}
          <div className="feed-post-link-title">{payload.title || 'Ссылка'}</div>
          <div className="feed-post-link-desc">{payload.desc || payload.subtitle || 'Материал со ссылкой.'}</div>
        </div>
      ) : null}

      {kind === 'repost' ? (
        <div className="feed-post-content-block feed-post-repost-card is-active">
          <div className="feed-post-repost-title">{payload.title || 'Репост'}</div>
          <div className="feed-post-repost-desc">{payload.desc || 'Подборка или репост из другого источника.'}</div>
          {(payload.innerTitle || payload.innerDesc) ? (
            <div className="repost-inner">
              <div className="feed-post-link-title">{payload.innerTitle || 'Внутренний материал'}</div>
              <div className="feed-post-link-desc">{payload.innerDesc || 'Краткое описание вложенного материала.'}</div>
            </div>
          ) : null}
        </div>
      ) : null}

      <div className="feed-post-footer profilePost-richFooter">
        <div className="profilePost-metaStrip">
          <span>+{post.stats.plus}</span>
          <span>{post.stats.comments} комм.</span>
          <span>{post.stats.saves} сохр.</span>
          <span>{post.stats.views} просмотров</span>
        </div>
        <div className="feed-post-social">
          <button className={`social-btn like-btn ${post.is_liked ? 'active' : ''}`} type="button" disabled={busyKey === `like:${post.id}`} onClick={() => onToggleLike?.(post)}>
            <svg viewBox="0 0 24 24"><path d="m12 20-1.1-1C6.14 14.24 3 11.39 3 7.86A4.86 4.86 0 0 1 7.86 3c1.76 0 3.45.82 4.14 2.09A4.83 4.83 0 0 1 16.14 3 4.86 4.86 0 0 1 21 7.86c0 3.53-3.14 6.38-7.9 11.13L12 20z"></path></svg>
            <span>{post.is_liked ? 'Нравится' : 'Лайк'}</span>
          </button>
          <button className={`social-btn comments-btn ${commentsOpen ? 'is-open' : ''}`} type="button" onClick={() => setCommentsOpen((prev) => !prev)}>
            <svg viewBox="0 0 24 24"><path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5c-1.3 0-2.53-.29-3.62-.8L3 21l1.92-5.38A8.47 8.47 0 0 1 4 11.5 8.5 8.5 0 1 1 21 11.5z"></path></svg>
            <span>{commentsOpen ? 'Скрыть' : 'Комментарии'}</span>
          </button>
          {allowSave ? (
            <button className={`social-btn save-btn ${post.is_saved ? 'active' : ''}`} type="button" disabled={busyKey === `save:${post.id}`} onClick={() => onToggleSave?.(post.id)}>
              <svg viewBox="0 0 24 24"><path d="M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1z"></path></svg>
              <span>{post.is_saved ? 'Сохранено' : 'Сохранить'}</span>
            </button>
          ) : null}
        </div>
      </div>

      {commentsOpen ? (
        <div className="profilePost-commentsInline">
          {onAddComment ? (
            <div className="comment-composer profilePost-commentComposerInline">
              <input
                className="comment-composer-input"
                type="text"
                value={commentText}
                onChange={(event) => setCommentText(event.target.value)}
                placeholder="Написать комментарий…"
                onKeyDown={(event) => {
                  if (event.key === 'Enter') {
                    event.preventDefault();
                    submitComment();
                  }
                }}
              />
              <button type="button" className="comment-composer-btn profilePost-sendBtnInline" onClick={submitComment}>
                <svg viewBox="0 0 24 24"><path d="m22 2-7 20-4-9-9-4Z"></path><path d="M22 2 11 13"></path></svg>
              </button>
            </div>
          ) : null}
          <div className="comment-list profilePost-commentListInline">
            {post.comments?.length ? post.comments.map((comment) => (
              <div className="comment-item" key={comment.id}>
                <div className="comment-layout">
                  <div className="comment-avatar"></div>
                  <div className="comment-main">
                    <div className="comment-top">
                      <div className="comment-name">{formatName(`${comment.author?.first_name || ''} ${comment.author?.last_name || ''}`.trim())}</div>
                      <div className="comment-time">{formatDateTime(comment.created_at)}{comment.edited ? ' · изм.' : ''}</div>
                    </div>
                    <div className="comment-text">{comment.text}</div>
                    <CommentInlineActions
                      comment={comment}
                      busyKey={busyKey}
                      onCommentVote={onCommentVote}
                      onCommentEdit={onCommentEdit}
                      onCommentDelete={onCommentDelete}
                    />
                  </div>
                </div>
              </div>
            )) : <div className="profilePost-emptyComments">Пока без комментариев.</div>}
          </div>
        </div>
      ) : null}
    </article>
  );
}
